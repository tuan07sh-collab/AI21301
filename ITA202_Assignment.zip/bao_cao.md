# BÁO CÁO DỰ ÁN MACHINE LEARNING
## Dự đoán Bệnh Tim (Heart Disease Classification)
### Môn: Học Máy Cơ Bản (ITA202) | Assignment 1

---

## 1. Giới thiệu Dự án

**Mục tiêu:** Xây dựng mô hình Machine Learning để dự đoán khả năng một bệnh nhân mắc bệnh tim dựa trên các chỉ số y tế.

**Bài toán:** Phân loại nhị phân (Binary Classification)
- Nhãn `0`: Không mắc bệnh tim
- Nhãn `1`: Có mắc bệnh tim

**Dataset:** Cleveland Heart Disease Dataset (UCI Machine Learning Repository)
- **Nguồn:** https://archive.ics.uci.edu/ml/datasets/heart+Disease
- **Kích thước:** 303 mẫu × 14 đặc trưng (13 features + 1 target)
- **Đặc điểm:** Dữ liệu y tế thực tế, có 6 giá trị khuyết thiếu

---

## 2. Mô tả Dữ liệu

| Đặc trưng | Mô tả | Kiểu |
|-----------|-------|------|
| `age` | Tuổi bệnh nhân (năm) | Số thực |
| `sex` | Giới tính (1=Nam, 0=Nữ) | Nhị phân |
| `cp` | Loại đau ngực (1–4) | Phân loại |
| `trestbps` | Huyết áp lúc nghỉ (mm Hg) | Số thực |
| `chol` | Cholesterol huyết thanh (mg/dl) | Số thực |
| `fbs` | Đường huyết lúc đói > 120 mg/dl | Nhị phân |
| `restecg` | Kết quả điện tâm đồ lúc nghỉ | Phân loại |
| `thalach` | Nhịp tim tối đa đạt được (bpm) | Số thực |
| `exang` | Đau thắt ngực do gắng sức | Nhị phân |
| `oldpeak` | ST depression so với lúc nghỉ | Số thực |
| `slope` | Độ dốc đoạn ST khi gắng sức | Phân loại |
| `ca` | Số mạch máu chính (0–3) | Số thực |
| `thal` | Kết quả Thalassemia | Phân loại |
| `target` | **Chẩn đoán bệnh tim** (0/1) | Nhãn |

**Phân phối nhãn:**
- Không bệnh (0): 164 mẫu (54.1%)
- Có bệnh tim (1): 139 mẫu (45.9%)

> [!NOTE]
> Dữ liệu tương đối cân bằng (không cần oversampling), phù hợp để huấn luyện mô hình phân loại trực tiếp.

---

## 3. Quy trình Thực hiện

```mermaid
flowchart TD
    A["📂 Thu thập dữ liệu\nUCI ML Repository\n303 mẫu × 14 cột"] --> B["🔍 Khám phá dữ liệu\nShape, Info, Describe"]
    B --> C["🧹 Làm sạch dữ liệu\nFill NaN bằng Median\nClip Outliers bằng IQR"]
    C --> D["⚙️ Tiền xử lý\nStandardScaler\nTrain 80% / Test 20%"]
    D --> E["🤖 Mô hình Cơ sở\nLogistic Regression\nAcc = 86.89%"]
    E --> F["🔬 Mô hình Nâng cao\nKNN, Decision Tree\nRandom Forest"]
    F --> G["🔧 Xây dựng Pipeline\nScaler + RandomForest"]
    G --> H["🎯 GridSearchCV\n5-Fold Cross-Validation\n36 tổ hợp × 5 Folds"]
    H --> I["📊 Đánh giá & So sánh\nAcc = 88.52% | AUC = 0.949"]
    I --> J["💾 Lưu Mô hình\nheart_disease_model.pkl"]
```

---

## 4. Giai đoạn 1: Mô hình Cơ sở

### 4.1 Làm sạch dữ liệu

| Vấn đề | Xử lý | Kết quả |
|--------|-------|---------|
| NaN trong `ca` (4 giá trị) | Điền bằng **Median = 0.0** | Loại bỏ hoàn toàn |
| NaN trong `thal` (2 giá trị) | Điền bằng **Median = 3.0** | Loại bỏ hoàn toàn |
| Outliers `trestbps` (9) | IQR Clipping [90, 170] | Giữ nguyên mẫu |
| Outliers `chol` (5) | IQR Clipping [115, 371] | Giữ nguyên mẫu |
| Outliers `thalach` (1) | IQR Clipping [84.8, 214.8] | Giữ nguyên mẫu |
| Outliers `oldpeak` (5) | IQR Clipping [-2.4, 4.0] | Giữ nguyên mẫu |

> [!TIP]
> Sử dụng **IQR Clipping** (thay vì xóa) để giữ toàn bộ 303 mẫu dữ liệu, tránh mất thông tin.

### 4.2 Tiền xử lý

- **Chia tập:** Train 80% (242 mẫu) / Test 20% (61 mẫu), stratified theo nhãn
- **Chuẩn hóa:** StandardScaler — fit trên train, transform cả train lẫn test
- **Phân bố sau chia:** Train {0:131, 1:111} | Test {0:33, 1:28}

### 4.3 Kết quả Logistic Regression

| Chỉ số | Giá trị |
|--------|---------|
| Train Accuracy | 84.71% |
| **Test Accuracy** | **86.89%** |
| Precision (avg) | 0.87 |
| Recall (avg) | 0.87 |
| F1-Score (avg) | 0.87 |

**Confusion Matrix:**
```
              Dự đoán 0   Dự đoán 1
Thực tế 0:      27          6
Thực tế 1:       2         26
```
- True Positive: 26 | False Negative: 2 ← Quan trọng (bỏ sót bệnh nhân có bệnh)
- True Negative: 27 | False Positive: 6

> [!NOTE]
> Chênh lệch train-test chỉ 2.17% → Mô hình ổn định, không có hiện tượng overfitting.

---

## 5. Giai đoạn 2: Tối ưu hóa

### 5.1 So sánh nhanh các mô hình (trước GridSearch)

| Mô hình | Train Acc | Test Acc | CV (5-fold) |
|---------|-----------|----------|-------------|
| Logistic Regression | 84.71% | 86.89% | — |
| KNN (k=5) | 88.02% | 85.25% | 83.47±4.50% |
| Decision Tree | **100%** | 81.97% | 74.35±5.73% |
| Random Forest | **100%** | 88.52% | 81.39±5.43% |

> [!WARNING]
> Decision Tree có Train Acc = 100% → **Overfitting nghiêm trọng**. Cần giới hạn `max_depth`.

### 5.2 Pipeline chuyên nghiệp

```python
Pipeline([
    ('scaler',     StandardScaler()),
    ('classifier', RandomForestClassifier(random_state=42))
])
```

### 5.3 GridSearchCV (5-Fold Cross-Validation)

**Không gian tìm kiếm:** 36 tổ hợp × 5 Folds = 180 lần fit

| Siêu tham số | Giá trị thử | Tốt nhất |
|-------------|-------------|----------|
| `n_estimators` | [50, 100, 200] | **50** |
| `max_depth` | [None, 5, 10] | **5** |
| `min_samples_split` | [2, 5] | **2** |
| `criterion` | ['gini', 'entropy'] | **gini** |

**CV Accuracy tốt nhất:** 83.04%

### 5.4 Kết quả Mô hình Tối ưu

| Chỉ số | Giá trị |
|--------|---------|
| **Test Accuracy** | **88.52%** |
| **AUC-ROC** | **0.9491** |
| Precision (avg) | 0.89 |
| Recall (avg) | 0.89 |
| F1-Score (avg) | 0.89 |

---

## 6. Bảng So sánh Tổng hợp

| Mô hình | Test Accuracy | Nhận xét |
|---------|--------------|----------|
| Logistic Regression (GĐ1) | 86.89% | Mô hình cơ sở, ổn định |
| KNN (k=5) | 85.25% | Thấp hơn cơ sở |
| Decision Tree | 81.97% | Overfitting nặng |
| Random Forest (default) | 88.52% | Tốt nhất trước GridSearch |
| **★ RF + GridSearchCV (GĐ2)** | **88.52%** | **Mô hình cuối, ổn định nhất** |

> [!IMPORTANT]
> RF + GridSearch đạt AUC = **0.9491** (rất tốt), trong khi Logistic Regression chỉ đạt AUC = 0.934. GridSearch giúp kiểm soát overfitting bằng `max_depth=5`.

---

## 7. Nhận xét và Kết luận

### Điểm mạnh của mô hình cuối:
- ✅ Accuracy 88.52% trên tập test độc lập
- ✅ AUC-ROC = 0.95 → Khả năng phân biệt tốt
- ✅ Recall bệnh tim = 0.93 → Ít bỏ sót bệnh nhân thực sự bệnh (quan trọng trong y tế)
- ✅ Pipeline tích hợp sẵn scaler → dễ triển khai và tránh data leakage

### Hướng cải thiện:
- Thêm kỹ thuật **Feature Engineering** (tạo đặc trưng mới)
- Thử **XGBoost / LightGBM** cho kết quả tốt hơn
- Thu thập thêm dữ liệu (303 mẫu còn ít)
- Áp dụng **SMOTE** nếu dữ liệu mất cân bằng

---

## 8. Hướng dẫn Sử dụng Mô hình

```python
import joblib
import pandas as pd

# Load mô hình (đã bao gồm scaler bên trong pipeline)
model = joblib.load('heart_disease_model.pkl')

# Dữ liệu bệnh nhân mới (1 mẫu)
patient = pd.DataFrame({
    'age': [55], 'sex': [1], 'cp': [3], 'trestbps': [130],
    'chol': [250], 'fbs': [0], 'restecg': [1], 'thalach': [150],
    'exang': [1], 'oldpeak': [1.5], 'slope': [2], 'ca': [0], 'thal': [3]
})

# Dự đoán (pipeline tự động chuẩn hóa dữ liệu)
prediction = model.predict(patient)
probability = model.predict_proba(patient)[:, 1]

print(f"Kết quả: {'Có bệnh tim' if prediction[0] == 1 else 'Không bệnh'}")
print(f"Xác suất mắc bệnh: {probability[0]:.2%}")
```

---

## 9. Danh sách File Sản phẩm

| File | Mô tả |
|------|-------|
| [`giai_doan_1.py`](giai_doan_1.py) | Code đầy đủ Giai đoạn 1 (Logistic Regression) |
| [`giai_doan_2.py`](giai_doan_2.py) | Code đầy đủ Giai đoạn 2 (Tối ưu hóa) |
| [`heart_disease_model.pkl`](heart_disease_model.pkl) | Pipeline mô hình tối ưu (194 KB) |
| [`scaler.pkl`](scaler.pkl) | StandardScaler đã fit |
| [`data_splits.pkl`](data_splits.pkl) | Dữ liệu đã xử lý & chia tập |
| [`giai_doan_1_visualization.png`](giai_doan_1_visualization.png) | 6 biểu đồ Giai đoạn 1 |
| [`giai_doan_2_visualization.png`](giai_doan_2_visualization.png) | 6 biểu đồ Giai đoạn 2 |

---

*Báo cáo được tạo tự động | ITA202 Assignment 1 | Dự đoán Bệnh tim*
