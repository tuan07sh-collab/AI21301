# =============================================================================
# GIAI ĐOẠN 1: Chuẩn bị dữ liệu và Xây dựng mô hình Cơ sở
# Dự án: Dự đoán bệnh tim (Heart Disease Classification)
# Dataset: Cleveland Heart Disease Dataset (UCI ML Repository)
# =============================================================================

import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')  # Non-interactive backend
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score, confusion_matrix, classification_report,
    ConfusionMatrixDisplay
)
import warnings
warnings.filterwarnings('ignore')

print("=" * 65)
print("GIAI ĐOẠN 1: CHUẨN BỊ DỮ LIỆU & MÔ HÌNH CƠ SỞ")
print("Dự án: Dự đoán bệnh tim (Heart Disease Classification)")
print("=" * 65)

# =============================================================================
# BƯỚC 1: CHỌN VÀ KHÁM PHÁ DỮ LIỆU
# =============================================================================
print("\n📊 BƯỚC 1: CHỌN VÀ KHÁM PHÁ DỮ LIỆU")
print("-" * 50)

column_names = [
    'age',        # Tuổi
    'sex',        # Giới tính (1=nam, 0=nữ)
    'cp',         # Loại đau ngực (1-4)
    'trestbps',   # Huyết áp lúc nghỉ (mm Hg)
    'chol',       # Cholesterol huyết thanh (mg/dl)
    'fbs',        # Đường huyết lúc đói > 120 mg/dl (1=đúng)
    'restecg',    # Kết quả điện tâm đồ lúc nghỉ (0-2)
    'thalach',    # Nhịp tim tối đa đạt được
    'exang',      # Đau thắt ngực do gắng sức (1=có)
    'oldpeak',    # ST depression do gắng sức
    'slope',      # Độ dốc đoạn ST khi gắng sức tối đa
    'ca',         # Số mạch máu chính (0-3) được nhuộm màu
    'thal',       # Thalassemia (1=bình thường; 2=cố định; 3=có thể phục hồi)
    'target'      # Chẩn đoán (0=không bệnh, >0=có bệnh tim)
]

# Tải dữ liệu từ UCI ML Repository
url = "https://archive.ics.uci.edu/ml/machine-learning-databases/heart-disease/processed.cleveland.data"
try:
    df = pd.read_csv(url, header=None, names=column_names, na_values='?')
    print(f"✅ Tải dữ liệu thành công từ UCI ML Repository")
except Exception as e:
    print(f"⚠️  Không thể kết nối URL ({e}). Tạo dữ liệu tương đương...")
    np.random.seed(42)
    n = 303
    df = pd.DataFrame({
        'age':      np.random.randint(29, 77, n).astype(float),
        'sex':      np.random.randint(0, 2, n).astype(float),
        'cp':       np.random.randint(1, 5, n).astype(float),
        'trestbps': np.random.randint(94, 200, n).astype(float),
        'chol':     np.random.randint(126, 564, n).astype(float),
        'fbs':      np.random.randint(0, 2, n).astype(float),
        'restecg':  np.random.randint(0, 3, n).astype(float),
        'thalach':  np.random.randint(71, 202, n).astype(float),
        'exang':    np.random.randint(0, 2, n).astype(float),
        'oldpeak':  np.round(np.random.uniform(0, 6.2, n), 1),
        'slope':    np.random.randint(1, 4, n).astype(float),
        'ca':       np.random.choice([0., 1., 2., 3., np.nan], n, p=[0.5,0.2,0.15,0.1,0.05]),
        'thal':     np.random.choice([3., 6., 7., np.nan], n, p=[0.1,0.5,0.35,0.05]),
        'target':   np.random.randint(0, 5, n).astype(float)
    })

# Chuyển target về nhị phân: 0=không bệnh, 1=có bệnh tim
df['target'] = df['target'].apply(lambda x: 1 if x > 0 else 0)

print(f"\n🔍 Thông tin cơ bản về dữ liệu:")
print(f"   • Số dòng (mẫu): {df.shape[0]}")
print(f"   • Số cột (đặc trưng + target): {df.shape[1]}")
print(f"\n📌 Tên các cột: {list(df.columns)}")

print(f"\n📋 df.info():")
print("-" * 40)
df.info()

print(f"\n📊 df.describe():")
print("-" * 40)
print(df.describe().round(2).to_string())

print(f"\n🎯 Phân phối nhãn (target):")
print(df['target'].value_counts())
print(f"   Tỷ lệ: {df['target'].value_counts(normalize=True).round(3).to_dict()}")

# =============================================================================
# BƯỚC 2: LÀM SẠCH DỮ LIỆU
# =============================================================================
print("\n\n🧹 BƯỚC 2: LÀM SẠCH DỮ LIỆU")
print("-" * 50)

# 2.1 Kiểm tra và xử lý giá trị khuyết thiếu (NaN)
print("📌 Giá trị khuyết thiếu (NaN) trước khi xử lý:")
missing = df.isnull().sum()
if missing.sum() > 0:
    print(missing[missing > 0])
else:
    print("   → Không có giá trị khuyết thiếu")

# Điền NaN bằng median (robust với outliers)
for col in df.columns:
    n_missing = df[col].isnull().sum()
    if n_missing > 0:
        med = df[col].median()
        df[col] = df[col].fillna(med)
        print(f"   → Điền NaN cột '{col}' ({n_missing} giá trị) bằng median = {med}")

print(f"\n✅ Sau xử lý NaN: {df.isnull().sum().sum()} giá trị thiếu còn lại")

# 2.2 Xử lý giá trị ngoại lệ (Outliers) bằng IQR Clipping
print("\n📌 Xử lý giá trị ngoại lệ (Outliers) bằng IQR Clipping:")
numeric_cols_check = ['trestbps', 'chol', 'thalach', 'oldpeak']
for col in numeric_cols_check:
    Q1 = df[col].quantile(0.25)
    Q3 = df[col].quantile(0.75)
    IQR = Q3 - Q1
    lower = Q1 - 1.5 * IQR
    upper = Q3 + 1.5 * IQR
    n_out = ((df[col] < lower) | (df[col] > upper)).sum()
    df[col] = df[col].clip(lower=lower, upper=upper)
    print(f"   • '{col}': {n_out} outliers → clip vào [{lower:.1f}, {upper:.1f}]")

# =============================================================================
# BƯỚC 3: TIỀN XỬ LÝ
# =============================================================================
print("\n\n⚙️  BƯỚC 3: TIỀN XỬ LÝ")
print("-" * 50)

# Tách features và target
X = df.drop('target', axis=1)
y = df['target']

print(f"📌 Kích thước X (features): {X.shape}")
print(f"📌 Kích thước y (target):   {y.shape}")
print(f"📌 Kiểm tra NaN trong X: {X.isnull().sum().sum()} (phải = 0)")

# Chia tập dữ liệu: 80% train, 20% test (stratified)
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)
print(f"\n✅ Chia dữ liệu (stratified split, random_state=42):")
print(f"   • X_train: {X_train.shape}  |  X_test: {X_test.shape}")
print(f"   • y_train phân bố: {y_train.value_counts().to_dict()}")
print(f"   • y_test  phân bố: {y_test.value_counts().to_dict()}")

# Chuẩn hóa dữ liệu: Fit trên train, transform cả train lẫn test
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled  = scaler.transform(X_test)

print(f"\n✅ Chuẩn hóa dữ liệu (StandardScaler):")
print(f"   • Mean train (sau chuẩn hóa): {X_train_scaled.mean():.6f} (≈0)")
print(f"   • Std  train (sau chuẩn hóa): {X_train_scaled.std():.6f} (≈1)")

# =============================================================================
# BƯỚC 4: HUẤN LUYỆN MÔ HÌNH CƠ SỞ - LOGISTIC REGRESSION
# =============================================================================
print("\n\n🤖 BƯỚC 4: HUẤN LUYỆN MÔ HÌNH CƠ SỞ")
print("-" * 50)
print("Mô hình: Logistic Regression (phù hợp bài toán phân loại nhị phân)")

lr_model = LogisticRegression(random_state=42, max_iter=1000, C=1.0, solver='lbfgs')
lr_model.fit(X_train_scaled, y_train)
print("✅ Huấn luyện Logistic Regression hoàn tất!")
print(f"   • Số vòng lặp hội tụ: {lr_model.n_iter_[0]}")

# =============================================================================
# BƯỚC 5: ĐÁNH GIÁ BAN ĐẦU
# =============================================================================
print("\n\n📈 BƯỚC 5: ĐÁNH GIÁ MÔ HÌNH CƠ SỞ")
print("-" * 50)

y_pred_train = lr_model.predict(X_train_scaled)
y_pred_test  = lr_model.predict(X_test_scaled)

acc_train = accuracy_score(y_train, y_pred_train)
acc_test  = accuracy_score(y_test,  y_pred_test)
cm        = confusion_matrix(y_test, y_pred_test)

print(f"🎯 Accuracy trên tập TRAIN: {acc_train:.4f} ({acc_train*100:.2f}%)")
print(f"🎯 Accuracy trên tập TEST:  {acc_test:.4f}  ({acc_test*100:.2f}%)")
print(f"\n   (Chênh lệch train-test: {abs(acc_train-acc_test):.4f} → ", end="")
if abs(acc_train - acc_test) < 0.05:
    print("Mô hình ổn định, không overfit)")
elif acc_train - acc_test > 0.05:
    print("Có dấu hiệu Overfitting nhẹ)")
else:
    print("Có dấu hiệu Underfitting)")

print(f"\n📋 Classification Report (tập Test):")
print(classification_report(y_test, y_pred_test,
                             target_names=['Không bệnh (0)', 'Có bệnh tim (1)']))

tn, fp, fn, tp = cm.ravel()
print(f"🔲 Confusion Matrix:")
print(f"   {cm}")
print(f"   • True Negative  (TN) = {tn}  → Dự đoán đúng KHÔNG bệnh")
print(f"   • False Positive (FP) = {fp}  → Dự đoán sai CÓ bệnh (thực tế không)")
print(f"   • False Negative (FN) = {fn}  → Dự đoán sai KHÔNG bệnh (thực tế có)")
print(f"   • True Positive  (TP) = {tp}  → Dự đoán đúng CÓ bệnh")

# =============================================================================
# TRỰC QUAN HÓA KẾT QUẢ
# =============================================================================
print("\n\n📊 Đang tạo biểu đồ trực quan hóa...")

fig, axes = plt.subplots(2, 3, figsize=(16, 10))
fig.suptitle(
    'GIAI ĐOẠN 1: Khám phá Dữ liệu & Mô hình Cơ sở (Logistic Regression)\n'
    'Dự án: Dự đoán Bệnh tim | Cleveland Heart Disease Dataset',
    fontsize=13, fontweight='bold'
)

# 1. Phân phối target
ax = axes[0, 0]
counts = df['target'].value_counts().sort_index()
bars = ax.bar(['Không bệnh (0)', 'Có bệnh tim (1)'],
              counts.values, color=['#27ae60', '#c0392b'], edgecolor='black', alpha=0.85)
for b, v in zip(bars, counts.values):
    ax.text(b.get_x() + b.get_width()/2, b.get_height() + 1,
            f'{v}\n({v/len(df)*100:.1f}%)', ha='center', fontsize=10, fontweight='bold')
ax.set_title('Phân phối nhãn (Target)', fontweight='bold')
ax.set_ylabel('Số lượng mẫu')
ax.set_ylim(0, max(counts.values) * 1.2)

# 2. Phân phối tuổi theo nhãn
ax = axes[0, 1]
df[df['target']==0]['age'].hist(ax=ax, bins=14, alpha=0.7, color='#27ae60', label='Không bệnh')
df[df['target']==1]['age'].hist(ax=ax, bins=14, alpha=0.7, color='#c0392b', label='Có bệnh tim')
ax.set_title('Phân phối Tuổi theo Nhãn', fontweight='bold')
ax.set_xlabel('Tuổi (năm)')
ax.set_ylabel('Số lượng')
ax.legend()
ax.grid(alpha=0.3)

# 3. Heatmap tương quan
ax = axes[0, 2]
corr = df.corr()
mask = np.triu(np.ones_like(corr, dtype=bool))
sns.heatmap(corr, ax=ax, mask=mask, cmap='coolwarm', center=0,
            annot=True, fmt='.2f', annot_kws={'size': 6},
            square=False, linewidths=0.3)
ax.set_title('Heatmap Tương quan các Đặc trưng', fontweight='bold')
ax.tick_params(labelsize=7)

# 4. Boxplot Nhịp tim tối đa vs Target
ax = axes[1, 0]
data0 = df[df['target']==0]['thalach']
data1 = df[df['target']==1]['thalach']
bp = ax.boxplot([data0, data1], patch_artist=True, notch=False,
                medianprops=dict(color='black', linewidth=2))
bp['boxes'][0].set_facecolor('#27ae60')
bp['boxes'][0].set_alpha(0.7)
bp['boxes'][1].set_facecolor('#c0392b')
bp['boxes'][1].set_alpha(0.7)
ax.set_xticklabels(['Không bệnh (0)', 'Có bệnh tim (1)'])
ax.set_title('Nhịp tim tối đa (thalach)\nvs Bệnh tim', fontweight='bold')
ax.set_ylabel('Nhịp tim tối đa (bpm)')
ax.grid(axis='y', alpha=0.3)

# 5. Confusion Matrix
ax = axes[1, 1]
disp = ConfusionMatrixDisplay(confusion_matrix=cm,
                              display_labels=['Không bệnh', 'Có bệnh'])
disp.plot(ax=ax, colorbar=False, cmap='Blues')
ax.set_title(f'Confusion Matrix – Logistic Regression\nTest Accuracy = {acc_test:.2%}',
             fontweight='bold')

# 6. Hệ số (Coefficients) Logistic Regression
ax = axes[1, 2]
coef_df = pd.DataFrame({
    'Feature': list(X.columns),
    'Coefficient': lr_model.coef_[0]
}).sort_values('Coefficient')
clrs = ['#c0392b' if c > 0 else '#2980b9' for c in coef_df['Coefficient']]
ax.barh(coef_df['Feature'], coef_df['Coefficient'], color=clrs,
        edgecolor='black', alpha=0.85)
ax.axvline(0, color='black', linewidth=1)
ax.set_title('Hệ số Logistic Regression\n(đỏ=tăng nguy cơ, xanh=giảm nguy cơ)',
             fontweight='bold')
ax.set_xlabel('Giá trị hệ số (Coefficient)')
ax.grid(axis='x', alpha=0.3)

plt.tight_layout()
plt.savefig('giai_doan_1_visualization.png', dpi=150, bbox_inches='tight')
plt.close()
print("✅ Biểu đồ đã được lưu: giai_doan_1_visualization.png")

# Lưu scaler và data splits để dùng ở giai đoạn 2
import joblib
joblib.dump(scaler, 'scaler.pkl')
joblib.dump({
    'X': X, 'y': y,
    'X_train': X_train, 'X_test': X_test,
    'y_train': y_train, 'y_test': y_test,
    'X_train_scaled': X_train_scaled,
    'X_test_scaled': X_test_scaled,
    'df': df
}, 'data_splits.pkl')
print("✅ Đã lưu: scaler.pkl, data_splits.pkl")

print("\n" + "=" * 65)
print("✅ HOÀN THÀNH GIAI ĐOẠN 1!")
print(f"   Logistic Regression → Test Accuracy = {acc_test*100:.2f}%")
print("   Sản phẩm: giai_doan_1_visualization.png, scaler.pkl, data_splits.pkl")
print("=" * 65)
