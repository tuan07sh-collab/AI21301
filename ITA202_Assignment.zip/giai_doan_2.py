# =============================================================================
# GIAI ĐOẠN 2: Tối ưu hóa và Hoàn thiện Dự án
# Dự án: Dự đoán bệnh tim (Heart Disease Classification)
# =============================================================================

import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import seaborn as sns
import joblib
import warnings
warnings.filterwarnings('ignore')

from sklearn.model_selection import train_test_split, GridSearchCV, cross_val_score
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.pipeline import Pipeline
from sklearn.metrics import (
    accuracy_score, confusion_matrix, classification_report,
    ConfusionMatrixDisplay, roc_curve, auc
)

print("=" * 65)
print("GIAI ĐOẠN 2: TỐI ƯU HÓA VÀ HOÀN THIỆN DỰ ÁN")
print("Dự án: Dự đoán bệnh tim (Heart Disease Classification)")
print("=" * 65)

# =============================================================================
# TẢI LẠI DỮ LIỆU ĐÃ XỬ LÝ TỪ GIAI ĐOẠN 1
# =============================================================================
print("\n📂 Tải dữ liệu đã xử lý từ Giai đoạn 1...")

data = joblib.load('data_splits.pkl')
X            = data['X']
y            = data['y']
X_train      = data['X_train']
X_test       = data['X_test']
y_train      = data['y_train']
y_test       = data['y_test']
X_train_scaled = data['X_train_scaled']
X_test_scaled  = data['X_test_scaled']

print(f"✅ Tải thành công từ data_splits.pkl")
print(f"   • X_train: {X_train.shape}  |  X_test: {X_test.shape}")
print(f"   • NaN trong X_train_scaled: {np.isnan(X_train_scaled).sum()}")
print(f"   • NaN trong X_test_scaled:  {np.isnan(X_test_scaled).sum()}")

# Kết quả cơ sở (Giai đoạn 1) để so sánh
lr_base = LogisticRegression(random_state=42, max_iter=1000, C=1.0, solver='lbfgs')
lr_base.fit(X_train_scaled, y_train)
acc_base = accuracy_score(y_test, lr_base.predict(X_test_scaled))
print(f"\n📌 [Tham chiếu GĐ1] Logistic Regression → Test Accuracy: {acc_base:.4f}")

# =============================================================================
# BƯỚC 6: THỬ NGHIỆM MÔ HÌNH NÂNG CAO
# =============================================================================
print("\n\n🔬 BƯỚC 6: THỬ NGHIỆM MÔ HÌNH NÂNG CAO")
print("-" * 50)

models_basic = {
    'KNN (k=5)':     KNeighborsClassifier(n_neighbors=5),
    'Decision Tree': DecisionTreeClassifier(random_state=42),
    'Random Forest': RandomForestClassifier(n_estimators=100, random_state=42),
}

print("So sánh nhanh các mô hình (trên dữ liệu đã chuẩn hóa):")
basic_results = {}
for name, model in models_basic.items():
    model.fit(X_train_scaled, y_train)
    acc_tr = accuracy_score(y_train, model.predict(X_train_scaled))
    acc_te = accuracy_score(y_test,  model.predict(X_test_scaled))
    cv_sc  = cross_val_score(model, X_train_scaled, y_train, cv=5, scoring='accuracy')
    basic_results[name] = acc_te
    print(f"   • {name:<20} | Train: {acc_tr:.4f} | Test: {acc_te:.4f} | "
          f"CV: {cv_sc.mean():.4f}±{cv_sc.std():.4f}")

# =============================================================================
# BƯỚC 7: XÂY DỰNG PIPELINE CHUYÊN NGHIỆP
# =============================================================================
print("\n\n🔧 BƯỚC 7: XÂY DỰNG PIPELINE CHUYÊN NGHIỆP")
print("-" * 50)

# Pipeline đóng gói StandardScaler + Random Forest
pipeline = Pipeline([
    ('scaler',     StandardScaler()),
    ('classifier', RandomForestClassifier(random_state=42))
])

print("✅ Pipeline chuyên nghiệp được xây dựng:")
print(f"   ┌─ Bước 1: StandardScaler  → Chuẩn hóa dữ liệu tự động")
print(f"   └─ Bước 2: RandomForest    → Phân loại")
print(f"\n{pipeline}")

# =============================================================================
# BƯỚC 8: TỐI ƯU HÓA SIÊU THAM SỐ (GridSearchCV + 5-Fold CV)
# =============================================================================
print("\n\n🎯 BƯỚC 8: TỐI ƯU HÓA SIÊU THAM SỐ (GridSearchCV + 5-Fold CV)")
print("-" * 50)

param_grid = {
    'classifier__n_estimators':      [50, 100, 200],
    'classifier__max_depth':         [None, 5, 10],
    'classifier__min_samples_split': [2, 5],
    'classifier__criterion':         ['gini', 'entropy']
}
n_combos = 3 * 3 * 2 * 2
print(f"🔍 Không gian tìm kiếm: {n_combos} tổ hợp × 5 Folds = {n_combos*5} lần fit")
print(f"   • n_estimators:      {param_grid['classifier__n_estimators']}")
print(f"   • max_depth:         {param_grid['classifier__max_depth']}")
print(f"   • min_samples_split: {param_grid['classifier__min_samples_split']}")
print(f"   • criterion:         {param_grid['classifier__criterion']}")
print("\n⏳ Đang chạy GridSearchCV... (vài giây)")

grid_search = GridSearchCV(
    estimator=pipeline,
    param_grid=param_grid,
    cv=5,
    scoring='accuracy',
    n_jobs=-1,
    verbose=0
)
grid_search.fit(X_train, y_train)

print(f"\n✅ Hoàn thành GridSearchCV!")
print(f"   • Tham số tốt nhất:    {grid_search.best_params_}")
print(f"   • CV Accuracy tốt nhất: {grid_search.best_score_:.4f} ({grid_search.best_score_*100:.2f}%)")

best_pipeline = grid_search.best_estimator_

# =============================================================================
# BƯỚC 9: ĐÁNH GIÁ VÀ SO SÁNH MÔ HÌNH
# =============================================================================
print("\n\n📊 BƯỚC 9: ĐÁNH GIÁ VÀ SO SÁNH MÔ HÌNH")
print("-" * 50)

y_pred_best  = best_pipeline.predict(X_test)
acc_best     = accuracy_score(y_test, y_pred_best)
cm_best      = confusion_matrix(y_test, y_pred_best)

print(f"📋 MÔ HÌNH TỐT NHẤT (Random Forest + GridSearchCV):")
print(f"   🎯 Test Accuracy: {acc_best:.4f} ({acc_best*100:.2f}%)")
print(f"\n{classification_report(y_test, y_pred_best, target_names=['Không bệnh', 'Có bệnh tim'])}")

# Bảng so sánh tổng hợp
print("=" * 55)
print("📈 BẢNG SO SÁNH TỔNG HỢP TẤT CẢ MÔ HÌNH:")
print("=" * 55)
print(f"   {'Mô hình':<35} {'Accuracy':>10}")
print(f"   {'-'*47}")
all_model_results = [
    ('Logistic Regression (Cơ sở - GĐ1)', acc_base),
] + [(name, acc) for name, acc in basic_results.items()] + [
    ('★ Random Forest + GridSearchCV (GĐ2)', acc_best)
]
for name, acc in all_model_results:
    marker = " ← BEST" if acc == max(a for _, a in all_model_results) and 'GĐ2' in name else ""
    print(f"   {name:<35} {acc:.4f}{marker}")

delta = acc_best - acc_base
print(f"\n   📌 Cải thiện so với cơ sở: {delta:+.4f} ({delta*100:+.2f}%)")

# =============================================================================
# BƯỚC 10: ĐÓNG GÓI MÔ HÌNH (Lưu file .pkl)
# =============================================================================
print("\n\n💾 BƯỚC 10: ĐÓNG GÓI VÀ LƯU MÔ HÌNH")
print("-" * 50)

# Lưu pipeline hoàn chỉnh (đã bao gồm scaler bên trong)
model_path = 'heart_disease_model.pkl'
joblib.dump(best_pipeline, model_path)
import os
file_size = os.path.getsize(model_path)
print(f"✅ Mô hình đã được lưu: {model_path}  ({file_size/1024:.1f} KB)")

# Kiểm tra load lại
loaded_model = joblib.load(model_path)
loaded_pred  = loaded_model.predict(X_test)
loaded_acc   = accuracy_score(y_test, loaded_pred)
match = "✓ Khớp!" if abs(loaded_acc - acc_best) < 1e-9 else "⚠️ Có sai khác!"
print(f"✅ Kiểm tra load lại mô hình → Accuracy: {loaded_acc:.4f}  {match}")

# =============================================================================
# TRỰC QUAN HÓA GIAI ĐOẠN 2
# =============================================================================
print("\n\n📊 Đang tạo biểu đồ tổng hợp Giai đoạn 2...")

fig, axes = plt.subplots(2, 3, figsize=(17, 11))
fig.suptitle(
    'GIAI ĐOẠN 2: Tối ưu hóa & So sánh Mô hình\n'
    'Dự án: Dự đoán Bệnh tim | Random Forest + GridSearchCV',
    fontsize=13, fontweight='bold'
)

# 1. So sánh Accuracy các mô hình
ax = axes[0, 0]
names_plot = ['LogReg\n(GĐ1)', 'KNN', 'DecTree', 'RF\n(default)', 'RF+\nGridSearch']
accs_plot  = [acc_base] + list(basic_results.values()) + [acc_best]
clrs_plot  = ['#95a5a6', '#3498db', '#e67e22', '#9b59b6', '#e74c3c']
bars = ax.bar(names_plot, accs_plot, color=clrs_plot, edgecolor='black', alpha=0.85)
for b, a in zip(bars, accs_plot):
    ax.text(b.get_x()+b.get_width()/2, b.get_height()+0.005,
            f'{a:.3f}', ha='center', fontsize=9, fontweight='bold')
ax.set_ylim(0.5, 1.05)
ax.set_title('So sánh Accuracy Các Mô hình', fontweight='bold')
ax.set_ylabel('Accuracy (Test Set)')
ax.axhline(acc_base, color='gray', linestyle='--', alpha=0.6, label='Baseline')
ax.legend(fontsize=8)
ax.grid(axis='y', alpha=0.3)

# 2. CV Results (top 10 tổ hợp GridSearch)
ax = axes[0, 1]
cv_df = pd.DataFrame(grid_search.cv_results_).nlargest(10, 'mean_test_score').reset_index()
ypos = range(len(cv_df))
ax.barh(ypos, cv_df['mean_test_score'], xerr=cv_df['std_test_score'],
        color='#3498db', alpha=0.8, edgecolor='black', capsize=4)
ax.set_yticks(ypos)
ax.set_yticklabels([f"Combo {i+1}" for i in range(len(cv_df))], fontsize=8)
ax.set_xlabel('Mean CV Accuracy')
ax.set_title(f'Top 10 Tổ hợp Siêu tham số\n(GridSearchCV – best={grid_search.best_score_:.3f})',
             fontweight='bold')
ax.axvline(grid_search.best_score_, color='red', linestyle='--', lw=1.5)
ax.grid(axis='x', alpha=0.3)

# 3. Confusion Matrix (Best Model)
ax = axes[0, 2]
disp = ConfusionMatrixDisplay(confusion_matrix=cm_best,
                              display_labels=['Không bệnh', 'Có bệnh'])
disp.plot(ax=ax, colorbar=False, cmap='Greens')
ax.set_title(f'Confusion Matrix – Best Model\n(RF+GridSearch | Acc={acc_best:.2%})',
             fontweight='bold')

# 4. ROC Curve: Best Model vs Baseline
ax = axes[1, 0]
y_prob_best = best_pipeline.predict_proba(X_test)[:, 1]
y_prob_base = lr_base.predict_proba(X_test_scaled)[:, 1]
fpr_b, tpr_b, _ = roc_curve(y_test, y_prob_best)
fpr_lr, tpr_lr, _ = roc_curve(y_test, y_prob_base)
auc_b  = auc(fpr_b,  tpr_b)
auc_lr = auc(fpr_lr, tpr_lr)
ax.plot(fpr_b,  tpr_b,  color='#e74c3c', lw=2, label=f'RF+GridSearch (AUC={auc_b:.3f})')
ax.plot(fpr_lr, tpr_lr, color='#3498db', lw=2, ls='--', label=f'LogReg Baseline (AUC={auc_lr:.3f})')
ax.plot([0,1],[0,1],'k--', alpha=0.4, label='Random Classifier (AUC=0.5)')
ax.set_xlabel('False Positive Rate')
ax.set_ylabel('True Positive Rate')
ax.set_title('ROC Curve: Best Model vs Baseline', fontweight='bold')
ax.legend(fontsize=8)
ax.grid(alpha=0.3)

# 5. Feature Importance (Random Forest Best)
ax = axes[1, 1]
rf_clf   = best_pipeline.named_steps['classifier']
feat_df  = pd.DataFrame({'Feature': X.columns,
                          'Importance': rf_clf.feature_importances_}).sort_values('Importance')
n_feat   = len(feat_df)
clrs_fi  = plt.cm.RdYlGn(np.linspace(0.15, 0.9, n_feat))
ax.barh(feat_df['Feature'], feat_df['Importance'], color=clrs_fi,
        edgecolor='black', alpha=0.85)
ax.set_title('Feature Importance\n(Random Forest Tối ưu)', fontweight='bold')
ax.set_xlabel('Mức độ quan trọng (Importance)')
ax.grid(axis='x', alpha=0.3)

# 6. 5-Fold CV Learning Curve
ax = axes[1, 2]
cv_best = cross_val_score(best_pipeline, X_train, y_train, cv=5, scoring='accuracy')
cv_base = cross_val_score(lr_base, X_train_scaled, y_train, cv=5, scoring='accuracy')
x_cv = np.arange(1, 6)
ax.plot(x_cv, cv_best, 'o-', color='#e74c3c', lw=2, ms=8,
        label=f'RF Best (μ={cv_best.mean():.3f})')
ax.plot(x_cv, cv_base, 's--', color='#3498db', lw=2, ms=8,
        label=f'LogReg (μ={cv_base.mean():.3f})')
ax.axhline(cv_best.mean(), color='#e74c3c', ls=':', alpha=0.6)
ax.axhline(cv_base.mean(), color='#3498db', ls=':', alpha=0.6)
ax.set_xlabel('Fold')
ax.set_ylabel('Accuracy')
ax.set_title('5-Fold Cross-Validation\nSo sánh Best Model vs Baseline', fontweight='bold')
ax.legend(fontsize=8)
ax.set_xticks(x_cv)
ax.grid(alpha=0.3)
ax.set_ylim(0.7, 1.0)

plt.tight_layout()
plt.savefig('giai_doan_2_visualization.png', dpi=150, bbox_inches='tight')
plt.close()
print("✅ Biểu đồ đã được lưu: giai_doan_2_visualization.png")

# =============================================================================
# TỔNG KẾT
# =============================================================================
print("\n" + "=" * 65)
print("✅ HOÀN THÀNH GIAI ĐOẠN 2!")
print(f"   Mô hình tốt nhất: Random Forest + GridSearchCV")
print(f"   Test Accuracy = {acc_best*100:.2f}%  |  AUC-ROC = {auc_b:.4f}")
print(f"   Cải thiện so với Logistic Regression: {(acc_best-acc_base)*100:+.2f}%")
print("=" * 65)
print("\n📂 DANH SÁCH FILE SẢN PHẨM:")
print("   • giai_doan_1.py                 → Code Giai đoạn 1 (Logistic Regression)")
print("   • giai_doan_2.py                 → Code Giai đoạn 2 (Tối ưu hóa)")
print("   • heart_disease_model.pkl        → Mô hình tối ưu (Pipeline hoàn chỉnh)")
print("   • scaler.pkl                     → Scaler (dùng riêng nếu cần)")
print("   • data_splits.pkl                → Dữ liệu đã xử lý & chia tập")
print("   • giai_doan_1_visualization.png  → Biểu đồ Giai đoạn 1")
print("   • giai_doan_2_visualization.png  → Biểu đồ Giai đoạn 2")
print("   • bao_cao.md                     → Báo cáo tổng hợp dự án")
